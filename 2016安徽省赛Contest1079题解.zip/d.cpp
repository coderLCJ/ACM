#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>
#include <algorithm>
using namespace std;
typedef long long ll;

int a[100005];

int main() {
  int T, n, m, q;
  for (scanf("%d", &T); T--;) {
    scanf("%d%d%d", &n, &m, &q);
    n = n * m;
    for (int i = 0; i < n; i++) scanf("%d", &a[i]);
    sort(a, a + n);
    for (; q--;) {
      int h;
      scanf("%d", &h);
      int idx = upper_bound(a, a + n, h) - a;
      printf("%d\n", n - idx);
    }
  }
  return 0;
}
