#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>
#include <algorithm>
using namespace std;
typedef long long ll;

int a[10005];

int main() {
  int T, n, k;
  for (scanf("%d", &T); T--;) {
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
      scanf("%d", a + i);
    }
    scanf("%d", &k);
    sort(a, a + n);
    int max_idx = unique(a, a + n) - a;
    printf("%d\n", a[max_idx - k]);
  }
  return 0;
}
