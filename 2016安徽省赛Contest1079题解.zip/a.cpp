#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>
#include <algorithm>
using namespace std;
typedef long long ll;

int main() {
  int n, ax, bx, ay, by;
  for (scanf("%d", &n); n--;) {
    scanf("%d%d%d%d", &ax, &ay, &bx, &by);
    printf("%d\n", abs(ax * ay - bx * by));
  }
  return 0;
}
